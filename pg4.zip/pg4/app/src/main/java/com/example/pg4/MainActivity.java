package com.example.pg4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ProgressBar s = (ProgressBar) findViewById(R.id.progressBar);
        s.setBackgroundColor(Color.BLACK);
    }
    public void exit(View view){
        AlertDialog.Builder adb=new AlertDialog.Builder(this);
        adb.setTitle("CONFORM TO CLOSE");
        adb.setMessage("HI HOW R U");
        adb.setCancelable(false);
        adb.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        adb.setNeutralButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"you clicke no",Toast.LENGTH_LONG).show();
            }
        });
        adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"you clied ncancel",Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog ad=adb.create();
        ad.show();
    }
}